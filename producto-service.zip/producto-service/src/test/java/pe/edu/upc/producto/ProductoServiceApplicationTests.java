package pe.edu.upc.producto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
